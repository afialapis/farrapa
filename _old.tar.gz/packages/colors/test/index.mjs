require('@babel/register')

require('./print')