const uvl = (v1, v2) => {
  return v1!=undefined ? v1 : v2
}

export {uvl}